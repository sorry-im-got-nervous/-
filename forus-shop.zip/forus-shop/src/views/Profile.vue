<template>
    <div class="home">
        <h1>Здесь будет информация о магазине</h1>
    </div>
</template>