<template>
    <div class="basket">
        <h1>Здесь будут покупки</h1>
    </div>
</template>