<template>
    <div class="about">
        <h1>Поиск товаров</h1>
    </div>
</template>